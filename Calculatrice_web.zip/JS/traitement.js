function AjouterCaractere_onclick(caractere)
{
	document.querySelector("input").value = document.querySelector("input").value + caractere;
	document.querySelector("#txtReponse").value = "";
}

function Calculer()
{
	var equation = 0;
	equation = document.querySelector("input").value;
	equation = eval(equation);
	document.querySelector("#txtReponse").value = equation;
	document.querySelector("#txtEquation").value = "";
}