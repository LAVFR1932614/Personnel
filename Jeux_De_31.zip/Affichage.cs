﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire_2_6
{
    class Affichage
    {
        /***********************************************Fonctions affichage************************************************************/

        /*Affiche les options dans un tour*/
        public static void AfficherDialogue(ref int indice)
        {
            switch (indice)
            {
                case (int)Indice.Options: Console.WriteLine("\nQue voulez vous faire?\n1-Prendre la carte du milieu\n2-Piger une carte dans le paquet\n3-Cogner"); break;
                case (int)Indice.OptionSiPigeCarte: Console.WriteLine("\n1-Remplacer votre premiere carte\n2-Remplacer deuxieme carte\n3-Remplacer troisième carte\n4-Rejeter la carte pigée"); break;
                case (int)Indice.OptionSiPrendCarteMilieu: Console.WriteLine("\n1-Remplacer votre premiere carte\n2-Remplacer deuxieme carte\n3-Remplacer troisième carte"); break;
                case (int)Indice.Intro:Console.WriteLine("Bienvenue dans le jeu du 31\nBonne chance!\nVoici les règles:\nVous devez vous approchez le plus possible d'un total de 31 avec vos 3 carte.\nPour que des cartes s'additionnent," +
                    "elles doivent être de la même sorte.\nLorsque vous croyez avoir un assez gros total, vous pouvez cogner,\nle tour sera alors terminer et le perdant sera dévoiler.\nSi vous perdez " +
                    "une manche, vous perdez un vie.\nVous ne pouvez pas cogner si vous avez un total inférieur à 21\n");break;
            }
        }

        /*Fonction qui affiche la "table" */
        public static void AfficherTable( ref Program.Joueur joueur, ref Program.Carte carteMilieuTable, int hauteurDepart)
        {
            CentrerTexte("Voici la table de jeux de "+joueur.nom,hauteurDepart);
            AfficherCarte(ref carteMilieuTable, ((Console.LargestWindowWidth / 4) - 5), hauteurDepart + 2);
            AfficherCarte(ref joueur.main[0], ((Console.LargestWindowWidth / 4) - 5) - 15, hauteurDepart + 12);
            AfficherCarte(ref joueur.main[1], ((Console.LargestWindowWidth / 4) - 5), hauteurDepart + 12);
            AfficherCarte(ref joueur.main[2], ((Console.LargestWindowWidth / 4) - 5) + 15, hauteurDepart + 12);

            /*Mettre le numero de chaque carte*/
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition((Console.LargestWindowWidth / 4) - 3, hauteurDepart + 5);
            Console.Write("Carte");
            Console.SetCursorPosition((Console.LargestWindowWidth / 4) - 3, hauteurDepart + 6);
            Console.Write("Milieu");
            Console.SetCursorPosition(((Console.LargestWindowWidth / 4) - 5) - 13, hauteurDepart + 16);
            Console.Write("Carte1");
            Console.SetCursorPosition(((Console.LargestWindowWidth / 4) - 5) + 2, hauteurDepart + 16);
            Console.Write("Carte2");
            Console.SetCursorPosition(((Console.LargestWindowWidth / 4) - 5) + 17, hauteurDepart + 16);
            Console.Write("Carte3");
            Console.ForegroundColor = ConsoleColor.White;

        }

        /*Fonction affichage carte*/

        public static void AfficherCarte(ref Program.Carte carteAAfficher, int departGauche, int departHaut)
        {
            char logo = 'c';
            int numeroEtage = 1;
            Console.SetCursorPosition(departGauche, departHaut);

            //Ajustements du symbole et de la couleur en fonction de la carte
            if (carteAAfficher.sorte == Sorte.Pique)
                logo = '♠';
            else if (carteAAfficher.sorte == Sorte.Coeur)
                logo = '♥';
            else if (carteAAfficher.sorte == Sorte.Carreau)
                logo = '♦';
            else if (carteAAfficher.sorte == Sorte.Trèfle)
                logo = '♣';
            if (carteAAfficher.sorte == Sorte.Carreau || carteAAfficher.sorte == Sorte.Coeur)
                Console.ForegroundColor = ConsoleColor.Red;

            //Affichage de la structure de la carte
            Console.Write("+--------+");
            Console.SetCursorPosition(departGauche, departHaut + numeroEtage);
            Console.Write("|" + logo);
            if((int)carteAAfficher.numero == 10)
                Console.SetCursorPosition(departGauche + 7, departHaut + numeroEtage);
            else
            Console.SetCursorPosition(departGauche + 8, departHaut + numeroEtage);
            Console.Write(carteAAfficher.numero + "|");
            numeroEtage++;
            Console.SetCursorPosition(departGauche, departHaut + numeroEtage);
            for (int i = 0; i < 5; i++)
            {
                Console.Write("|");
                Console.SetCursorPosition(departGauche + 9, departHaut + numeroEtage);
                Console.Write("|");
                numeroEtage++;
                Console.SetCursorPosition(departGauche, departHaut + numeroEtage);
            }
            numeroEtage++;
            Console.Write("|" + carteAAfficher.numero);
            Console.SetCursorPosition(departGauche + 8, departHaut + numeroEtage - 1);
            Console.Write(logo + "|");
            Console.SetCursorPosition(departGauche, departHaut + numeroEtage);
            Console.Write("+--------+");

            //On remet la couleur de la police à sa couleur d'origine
            Console.ForegroundColor = ConsoleColor.White;
        }


        /*Fonction qui permet de centrer le texte à l'écran*/

        public static void CentrerTexte(string texte, int hauteur)
        {
            Console.SetCursorPosition((Console.LargestWindowWidth / 4) - (texte.Length) / 2, hauteur);
            Console.Write(texte);
        }
    }
}