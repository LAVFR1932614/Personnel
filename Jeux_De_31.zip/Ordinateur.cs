﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Laboratoire_2_6
{
    class Ordinateur
    {
        /***********************************************Fonctions reliées seulement à l'ordinateur************************************************************/

        /*Fonction pour l'animation de jeu de l'ordinateur*/

        public static void AnimationDeJeux(ref Program.Joueur joueur)
        {
            Console.Clear();
            Affichage.CentrerTexte(joueur.nom + " est entrain de jouer",15);
            for (int i = 0; i < 3; i++)
            {
                Console.Write(" .");
                Thread.Sleep(1000);
            }
        }

        /*Fonction qui renvoie la carte dont la valeur n'est pas en double*/

        public static int NumeroUnique(ref Program.Joueur joueur)
        {
            int indice = 0;
            for (int i = 0; i < joueur.main.Length; i++)
            {
                if ((int)joueur.main[i].numero != joueur.infos.valeurRepetition)
                    indice = i;
            }
            return indice;
        }


        /*Fonction qui renvoie la plus petite valeur de carte*/

        public static int PetiteValeurCarte(ref Program.Carte[] mainATester)
        {
            int valeurPlusPetiteCarte = 100, indicePlusPetiteCarte = 0;
            for (int i = 0; i < mainATester.Length; i++)
            {
                if (mainATester[i].valeur < valeurPlusPetiteCarte)
                {
                    indicePlusPetiteCarte = i;
                    valeurPlusPetiteCarte = mainATester[i].valeur;
                }
            }
            return indicePlusPetiteCarte;
        }

        /*Fonction pour calculer joueur.total*/

        public static void CalculerTotal(ref Program.Joueur joueur)
        {
            for (int i = 0; i < joueur.total.Length; i++)
            {
                joueur.total[i].valeur = 0;
            }

            if (joueur.main[0].sorte == joueur.main[1].sorte && joueur.main[1].sorte == joueur.main[2].sorte)
            {
                joueur.total[(int)joueur.main[0].sorte].valeur = (int)joueur.main[0].valeur + (int)joueur.main[1].valeur + joueur.main[2].valeur;
                joueur.total[(int)joueur.main[0].sorte].sorte = joueur.main[0].sorte;
            }
            else if (joueur.main[0].sorte == joueur.main[1].sorte)
            {
                joueur.total[(int)joueur.main[0].sorte].valeur = (int)joueur.main[0].valeur + joueur.main[1].valeur;
                joueur.total[(int)joueur.main[2].sorte].valeur = joueur.main[2].valeur;
                joueur.total[(int)joueur.main[0].sorte].sorte = joueur.main[0].sorte;
                joueur.total[(int)joueur.main[2].sorte].sorte = joueur.main[2].sorte;
            }
            else if (joueur.main[0].numero == joueur.main[1].numero && joueur.main[0].numero == joueur.main[2].numero)
            {
                joueur.infos.valeurPlusGrandTotal = 30;
            }
            else if (joueur.main[0].sorte == joueur.main[2].sorte)
            {
                joueur.total[(int)joueur.main[0].sorte].valeur = (int)joueur.main[0].valeur + joueur.main[2].valeur;
                joueur.total[(int)joueur.main[1].sorte].valeur = joueur.main[1].valeur;
                joueur.total[(int)joueur.main[0].sorte].sorte = joueur.main[0].sorte;
                joueur.total[(int)joueur.main[1].sorte].sorte = joueur.main[1].sorte;
            }
            else if (joueur.main[1].sorte == joueur.main[2].sorte)
            {
                joueur.total[(int)joueur.main[1].sorte].valeur = (int)joueur.main[1].valeur + joueur.main[2].valeur;
                joueur.total[(int)joueur.main[0].sorte].valeur = joueur.main[0].valeur;
                joueur.total[(int)joueur.main[1].sorte].sorte = joueur.main[1].sorte;
                joueur.total[(int)joueur.main[0].sorte].sorte = joueur.main[0].sorte;
            }

            else
            {
                joueur.total[(int)joueur.main[0].sorte].valeur = joueur.main[0].valeur;
                joueur.total[(int)joueur.main[0].sorte].sorte = joueur.main[0].sorte;
                joueur.total[(int)joueur.main[1].sorte].valeur = joueur.main[1].valeur;
                joueur.total[(int)joueur.main[1].sorte].sorte = joueur.main[1].sorte;
                joueur.total[(int)joueur.main[2].sorte].valeur = joueur.main[2].valeur;
                joueur.total[(int)joueur.main[2].sorte].sorte = joueur.main[2].sorte;
            }
            joueur.total[0].valeur = 0;
        }

        /*Fonction pour calculer valeurs utiles*/

        public static void CalculerValeursUtiles(ref Program.Joueur joueur)
        {
            for (int i = 1; i < joueur.total.Length; i++)
            {
                if (joueur.total[i].valeur > joueur.infos.valeurPlusGrandTotal)
                {
                    joueur.infos.valeurPlusGrandTotal = joueur.total[i].valeur;
                    joueur.infos.sortePlusGrandTotal = joueur.total[i].sorte;
                }
            }
            joueur.infos.valeurPlusPetiteCarte = (int)joueur.infos.valeurPlusGrandTotal;
            for (int i = 0; i < joueur.main.Length; i++)
            {
                if (joueur.main[i].valeur < joueur.infos.valeurPlusPetiteCarte)
                {
                    joueur.infos.valeurPlusPetiteCarte = joueur.main[i].valeur;
                    joueur.infos.sortePlusPetiteCarte = joueur.main[i].sorte;
                    joueur.infos.positionPlusPetiteDansLaMain = i;
                }
            }
            for (int i = 0; i < joueur.main.Length; i++)
            {
                int compteur = 0;
                for (int j = 0; j < joueur.main.Length; j++)
                {
                    if (joueur.main[j].numero == joueur.main[i].numero)
                        compteur++;
                }
                if (compteur > joueur.infos.nombreRepetition)
                {
                    joueur.infos.nombreRepetition = compteur;
                    joueur.infos.valeurRepetition = (int)joueur.main[i].numero;
                }
            }
        }

        /*Fonction pour la prise de décision*/

        public static int PriseDecisionOrdinateur(ref Program.Carte[] paquetCarte, ref Program.Joueur joueur, ref Program.Carte carteATester, ref int indice, ref Program.Carte nuage)
        {
            if (joueur.infos.valeurPlusGrandTotal >= 21)
            {
                indice = (int)Indice.Identifiant_Ordinateur;
                Program.Cogner(ref joueur, ref indice);
            }
            else if (joueur.infos.valeurRepetition == 3)
            {
                indice = (int)Indice.Identifiant_Ordinateur;
                Program.Cogner(ref joueur, ref indice);
            }
            else if (carteATester.sorte == joueur.infos.sortePlusGrandTotal && joueur.main[0].sorte == joueur.main[1].sorte && joueur.main[0].sorte == joueur.main[2].sorte)
            {
                int plusPetiteCarte = PetiteValeurCarte(ref joueur.main);
                Program.InverserDeuxCartes(ref joueur.main[plusPetiteCarte], ref carteATester);
            }
            else if (carteATester.valeur > joueur.infos.valeurPlusPetiteCarte && joueur.infos.sortePlusGrandTotal != joueur.infos.sortePlusPetiteCarte)
            {
                Program.InverserDeuxCartes(ref carteATester, ref joueur.main[joueur.infos.positionPlusPetiteDansLaMain]);
            }
            else if (joueur.infos.nombreRepetition == 2 && (int)carteATester.numero == joueur.infos.valeurRepetition)
            {
                int CarteUnique = NumeroUnique(ref joueur);
                Program.InverserDeuxCartes(ref carteATester, ref joueur.main[CarteUnique]);
            }
            else if (indice == (int)Indice.OptionFinale)
            {
                int plusPetiteCarte = PetiteValeurCarte(ref joueur.main);
                Program.InverserDeuxCartes(ref joueur.main[plusPetiteCarte], ref carteATester);
            }
            else
            {
                return 2;
            }
            if (indice == (int)Indice.OptionFinale)
                Program.InverserDeuxCartes(ref nuage, ref carteATester);

            return 1;
        }
    }
}