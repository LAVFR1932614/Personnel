﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Laboratoire_2_6
{
    enum Sorte { Coeur = 1, Pique = 2, Carreau = 3, Trèfle = 4 }
    enum Numero { A = 1, J = 11, Q = 12, K = 13 }
    enum Indice { Options = 0, Piger = 1, Prendre = 2, Cogner = 3, Intro = 4, OptionSiPigeCarte = 5, OptionSiPrendCarteMilieu = 6, Identifiant_Utilisateur = 7, Identifiant_Ordinateur = 8, OptionFinale = 9, regles = 10 }
    enum TypeJoueur { Utilisateur = 1, Ordinateur = 2, Mort = 3 }

    class Program
    {
        static Random generateur = new Random();

        public struct Carte
        {
            public Sorte sorte;
            public Numero numero;
            public int valeur;
            public bool use;

            public Carte(Sorte _sorte, Numero _num, int _valeur = 0, bool _use = false) : this()
            {
                sorte = _sorte;
                numero = _num;
                valeur = _valeur;
                use = _use;
            }
        }
        public struct InfosUtiles
        {
            public int valeurPlusPetiteCarte;
            public Sorte sortePlusPetiteCarte;
            public int valeurPlusGrandTotal;
            public Sorte sortePlusGrandTotal;
            public int valeurRepetition;
            public int nombreRepetition;
            public int positionPlusPetiteDansLaMain;

            public InfosUtiles(int _valeur, Sorte _sortePlusPetite, int _valeurPlusGrandTotal, Sorte _sortePlusGrandTotal, int _nombre, int _positionDansLaMain, int _valeurRepetition) : this()
            {
                valeurPlusPetiteCarte = _valeur;
                sortePlusPetiteCarte = _sortePlusPetite;
                valeurPlusGrandTotal = _valeurPlusGrandTotal;
                sortePlusGrandTotal = _sortePlusGrandTotal;
                valeurRepetition = _valeurRepetition;
                nombreRepetition = _nombre;
                positionPlusPetiteDansLaMain = _positionDansLaMain;
            }
        }
        public struct Joueur
        {
            public int nombreDeVies;
            public Carte[] main;
            public Carte[] total;
            public TypeJoueur type;
            public string nom;
            public bool cogner;
            public InfosUtiles infos;

            public Joueur(int _nombreDeVies, Carte[] _main, Carte[] _total, TypeJoueur _type, string _nom, bool _cogner, InfosUtiles _infos) : this()
            {
                nombreDeVies = _nombreDeVies;
                main = _main;
                total = _total;
                type = _type;
                nom = _nom;
                cogner = _cogner;
                infos = _infos;
            }

        }
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            /*Variables*/
            Carte[] paquetCarte = new Carte[52];
            Carte carteMilieuTable = new Carte(0, 0, 0, false);
            int nbDeJoueurs = 0, nbDeVies = 0, indice = (int)Indice.Intro;

            Initialisation.PreparerConsole();
            Affichage.AfficherDialogue(ref indice);

            EntrerParametres(ref nbDeJoueurs, ref nbDeVies);
            Joueur[] tabJoueur = new Joueur[nbDeJoueurs];
            Initialisation.InitialiserPaquetCartes(ref paquetCarte);

            for (int i = 0; i < tabJoueur.Length; i++)
            {
                Initialisation.InitialiserJoueurs(ref paquetCarte, ref nbDeVies, ref tabJoueur[i]);
                tabJoueur[i].nombreDeVies = nbDeVies;
            }

            Jouer(ref paquetCarte, ref tabJoueur, ref carteMilieuTable, ref indice);

            Console.ReadKey();
        }


        /***********************************************Utilities************************************************************/

        /*Générateur de nombre aléatoire différent*/
        public static int GenererNombre(int min, int max)
        {
            int nombreAleatoire = 0;
            nombreAleatoire = generateur.Next(min, max);
            return nombreAleatoire;
        }

        /*Fonction qui génère une carte*/

        public static void GenererCarte(ref Carte[] paquetCarte, ref Carte carteAModifier)
        {
            bool quitter = false;
            int nombreAleatoire = 0;
            Carte carteGeneree = new Carte(Sorte.Coeur, Numero.A, 0, false);
            do
            {
                nombreAleatoire = GenererNombre(0, 51);
                if (paquetCarte[nombreAleatoire].use == false)
                {
                    carteAModifier = paquetCarte[nombreAleatoire];
                    paquetCarte[nombreAleatoire].use = true;
                    quitter = true;
                }
            } while (quitter != true);
            //return carteGeneree;
        }


        /*Fonction pour inverser deux carte*/

        public static void InverserDeuxCartes(ref Carte premiereCarte, ref Carte deuxiemeCarte)
        {
            Carte nuage = new Carte(Sorte.Coeur, 0, 0, false);

            nuage = premiereCarte;
            premiereCarte = deuxiemeCarte;
            deuxiemeCarte = nuage;
        }

        /*Fonction retournant nom gagnant*/

        static string NomGagnant(ref Joueur[] tabJoueur)
        {
            string nomGagnant = "Default";
            int valeurPlusGrand = 0;

            for (int i = 0; i < tabJoueur.Length; i++)
            {
                if (tabJoueur[i].infos.valeurPlusGrandTotal > valeurPlusGrand)
                {
                    valeurPlusGrand = tabJoueur[i].infos.valeurPlusGrandTotal;
                    nomGagnant = tabJoueur[i].nom;
                }
            }
            return nomGagnant;
        }

        /*Fonction retournant nom perdant*/
        static string NomPerdant(ref Joueur[] tabJoueur, ref bool terminer)
        {
            string nomPerdant = "Default";
            int valeurPlusGrand = 100, indice = 0, compteur = tabJoueur.Length;

            for (int i = 0; i < tabJoueur.Length; i++)
            {
                if (tabJoueur[i].type == TypeJoueur.Mort) ;//On enleve les joeurs morts du comptage
                else if (tabJoueur[i].infos.valeurPlusGrandTotal < valeurPlusGrand)
                {
                    valeurPlusGrand = tabJoueur[i].infos.valeurPlusGrandTotal;
                    indice = i;
                }
            }
            nomPerdant = tabJoueur[indice].nom;
            tabJoueur[indice].nombreDeVies--;//on enleve un vie au joueur perdant

            if (tabJoueur[indice].nombreDeVies == 0)
            {
                tabJoueur[indice].type = TypeJoueur.Mort;//si le perdant na plus de vie, on le met en tant que mort
            }
            for (int j = 0; j < tabJoueur.Length; j++)
            {
                if (tabJoueur[j].type == TypeJoueur.Mort)
                    compteur--;//On compte combien il reste de joueur en vie
            }
            if (compteur == 1)
                terminer = true;//si il reste seulement un joeur, on termine la partie
            return nomPerdant;
        }

        /*Fonction permettant d'entrer les parametres*/

        public static void EntrerParametres(ref int nbDeJoueurs, ref int nbDeVies)
        {

            Console.Write("\nVeuillez tout d'abord entrer les informations suivante:\nNombre de joueurs(Entre 2 et 4):");
            nbDeJoueurs = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nNombre de vies de chaque joueur:");
            nbDeVies = Convert.ToInt32(Console.ReadLine());

        }

        /*Fonction piger nouvelle carte*/

        static void PigerNouvelleCarte(ref Carte[] paquetCarte, ref Joueur joueur, ref Carte carteMilieuTable, ref int indice)
        {
            Carte cartePigee = new Carte(Sorte.Coeur, Numero.A, 0, false);
            GenererCarte(ref paquetCarte, ref cartePigee);

            Affichage.AfficherCarte(ref cartePigee, ((Console.LargestWindowWidth / 4) - 5), 22);
            Console.SetCursorPosition((Console.LargestWindowWidth / 4) - 3, 25);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Carte");
            Console.SetCursorPosition((Console.LargestWindowWidth / 4) - 3, 26);
            Console.Write("Pigée");
            Console.ForegroundColor = ConsoleColor.White;

            indice = (int)Indice.OptionSiPigeCarte;
            Affichage.AfficherDialogue(ref indice);
            RemplacerCarte(ref joueur.main, ref cartePigee, ref carteMilieuTable);
        }
        /*Fonction pour prendre carte milieu*/

        static void PrendreCarteMilieu(ref Carte[] paquetCarte, ref Joueur joueur, ref Carte carteMilieuTable, ref int indice)
        {
            indice = (int)Indice.OptionSiPrendCarteMilieu;
            Affichage.AfficherDialogue(ref indice);
            RemplacerCarte(ref joueur.main, ref carteMilieuTable, ref carteMilieuTable);
            Console.Clear();
            Affichage.AfficherTable(ref joueur, ref carteMilieuTable, 0);
        }
        /*Fonction cogner*/

        public static void Cogner(ref Joueur joueur, ref int indice)
        {
            if (indice == (int)Indice.Identifiant_Utilisateur)
            {
                Ordinateur.CalculerTotal(ref joueur);
                Ordinateur.CalculerValeursUtiles(ref joueur);
                if (joueur.infos.valeurPlusGrandTotal < 21)
                {
                    Console.WriteLine("Vous ne pouviez pas cogner puisque vous n'avez pas au moins 21.  Vous perdez un tour pour votre stupidité\nAppuyez sur un touche pour continuer");
                    Console.ReadKey();
                }

                else
                {
                    Affichage.CentrerTexte("Vous avez cogné, il reste maintenant un tour à vos adversaire.", 26);
                    Thread.Sleep(2000);
                    joueur.cogner = true;//On arrete la manche à la fin du tour

                }
            }
            else
            {
                Affichage.CentrerTexte("L'ordinateur a cogné.  Il vous reste un tour à jouer.", 17);
                Affichage.CentrerTexte("Appuyez sur une touche pour continuer", 18);
                Console.ReadKey();
                joueur.cogner = true;//On arrete la manche à la fin du tour
            }


        }
        /*Fonction pour remplacer une carte*/
        static void RemplacerCarte(ref Carte[] mainAModifier, ref Carte carteQuiRemplace, ref Carte carteMilieuTable)
        {
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1: InverserDeuxCartes(ref mainAModifier[0], ref carteQuiRemplace); break;
                case 2: InverserDeuxCartes(ref mainAModifier[1], ref carteQuiRemplace); break;
                case 3: InverserDeuxCartes(ref mainAModifier[2], ref carteQuiRemplace); break;
                case 4: InverserDeuxCartes(ref carteMilieuTable, ref carteQuiRemplace); break;
            }
        }
        /*Fonction pour analyser le choix d'action de l'utilisateur*/

        static void AnalyserChoix(ref Carte[] paquetCarte, ref Joueur joueur, ref Carte carteMilieuTable, ref int indice)
        {
            indice = (int)Indice.Options;
            Affichage.AfficherDialogue(ref indice);
            int choix = Convert.ToInt32(Console.ReadLine());
            switch (choix)
            {
                case 1:; PrendreCarteMilieu(ref paquetCarte, ref joueur, ref carteMilieuTable, ref indice); break;
                case 2:; PigerNouvelleCarte(ref paquetCarte, ref joueur, ref carteMilieuTable, ref indice); break;
                case 3:; indice = (int)Indice.Identifiant_Utilisateur; Cogner(ref joueur, ref indice); break;
            }
        }

        /*Fonction qui détermine le gagnant*/

        static void FinDeManche(ref Joueur[] tabJoueur, ref Carte carteMilieuTable, ref bool terminier)
        {
            string gagnant = "Default", perdant = "Default";

            for (int i = 0; i < tabJoueur.Length; i++)
            {
                Ordinateur.CalculerTotal(ref tabJoueur[i]);
            }

            for (int i = 0; i < tabJoueur.Length; i++)
            {
                Ordinateur.CalculerValeursUtiles(ref tabJoueur[i]);
            }

            Console.Clear();
            int hauteurDepart = 2;
            for (int i = 0; i < tabJoueur.Length; i++)
            {
                if (tabJoueur[i].type == TypeJoueur.Mort) ;//On n'affiche pas la main des joueurs morts

                else
                {
                    Affichage.AfficherTable(ref tabJoueur[i], ref carteMilieuTable, hauteurDepart);
                    hauteurDepart = hauteurDepart + 24;
                }
            }

            gagnant = NomGagnant(ref tabJoueur);
            perdant = NomPerdant(ref tabJoueur, ref terminier);


            Affichage.CentrerTexte("Le gagnant est : " + gagnant, hauteurDepart);
            Affichage.CentrerTexte("" + perdant + " Perd une vie.", hauteurDepart + 1);
            Affichage.CentrerTexte("Appuyez sur une touche pour contiuner", hauteurDepart + 2);
            Console.ReadKey();



        }

        /***********************************************Fonctions de jeu************************************************************/

        /*Fonction principale permettant de jouer*/
        static void Jouer(ref Carte[] paquetCarte, ref Joueur[] tabJoueur, ref Carte carteMilieuTable, ref int indice)
        {
            bool terminer = false, finManche = false;
            int nombreDeManches = 0;
            GenererCarte(ref paquetCarte, ref carteMilieuTable);


            while (terminer == false)
            {
                indice = (int)Indice.Options;
                int i = 0;
                nombreDeManches++;
                finManche = false;

                Console.Clear();
                Console.SetCursorPosition((Console.LargestWindowWidth / 4) - 4, 15);
                Affichage.CentrerTexte("Manche " + nombreDeManches, 15);
                Thread.Sleep(1000);

                while (finManche == false)
                {

                    if (tabJoueur[i].cogner == true)
                    {
                        finManche = true;
                        FinDeManche(ref tabJoueur, ref carteMilieuTable, ref terminer);
                        PreparationProchaineManche(ref paquetCarte, ref tabJoueur, ref carteMilieuTable);
                    }

                    else
                    {
                        if (tabJoueur[i].type == TypeJoueur.Utilisateur)
                            TourUtilisateur(ref paquetCarte, ref tabJoueur[i], ref carteMilieuTable, ref indice);
                        else if (tabJoueur[i].type == TypeJoueur.Ordinateur)
                            TourOrdinateur(ref paquetCarte, ref tabJoueur[i], ref carteMilieuTable, ref indice);
                    }
                    i++;
                    if (i == tabJoueur.Length)
                        i = 0;
                }
            }
            Console.Clear();
            Affichage.CentrerTexte("Fin de la partie.", 4);
            Affichage.CentrerTexte("Merci d'avoir jouer!", 5);
        }

        /*Fonction pour un tour utilisateur*/
        static void TourUtilisateur(ref Carte[] paquetCarte, ref Joueur joueur, ref Carte carteMilieuTable, ref int indice)
        {
            Console.Clear();
            Affichage.AfficherTable(ref joueur, ref carteMilieuTable, 0);
            AnalyserChoix(ref paquetCarte, ref joueur, ref carteMilieuTable, ref indice);
        }

        /*Fonction pour un tour ordinateur*/

        static void TourOrdinateur(ref Carte[] paquetCarte, ref Joueur joueur, ref Carte carteMilieuTable, ref int indice)
        {
            Carte cartePigee = new Carte(Sorte.Coeur, Numero.J, 10, false);
            Ordinateur.AnimationDeJeux(ref joueur);
            Ordinateur.CalculerTotal(ref joueur);
            Ordinateur.CalculerValeursUtiles(ref joueur);
            if (Ordinateur.PriseDecisionOrdinateur(ref paquetCarte, ref joueur, ref carteMilieuTable, ref indice, ref cartePigee) == 2)
            {
                indice = (int)Indice.OptionFinale;
                GenererCarte(ref paquetCarte, ref cartePigee);
                Ordinateur.PriseDecisionOrdinateur(ref paquetCarte, ref joueur, ref cartePigee, ref indice, ref carteMilieuTable);
                indice = 0;//On remet l'indice zéro afin d'éviter les problème lorqu'il y a plus de 2 joueurs
            }

        }
        /*Fonction qui prépare pour une autre manche*/

        static void PreparationProchaineManche(ref Carte[] paquetCarte, ref Joueur[] tabJoueur, ref Carte carteMilieuTable)
        {
            Joueur nuage = new Joueur(0, new Carte[3], new Carte[5], TypeJoueur.Utilisateur, "Default", false, new InfosUtiles());
            for (int k = 0; k < paquetCarte.Length; k++)
            {
                paquetCarte[k].use = false;
            }
            for (int i = 0; i < tabJoueur.Length; i++)
            {
                tabJoueur[i].cogner = false;
                for (int j = 0; j < tabJoueur[i].main.Length; j++)
                {
                    GenererCarte(ref paquetCarte, ref tabJoueur[i].main[j]);
                }
            }
            GenererCarte(ref paquetCarte, ref carteMilieuTable);
            for (int i = 0; i < tabJoueur.Length; i++)
            {
                tabJoueur[i].infos = nuage.infos;//On remet les infos utiles des joueurs à zero
            }
        }


    }
}