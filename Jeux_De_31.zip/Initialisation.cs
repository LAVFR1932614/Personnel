﻿using System;

namespace Laboratoire_2_6
{
    class Initialisation
    {
        /*Fonction qui initialise un joueur*/

        public static void InitialiserJoueurs(ref Program.Carte[] paquetCarte, ref int nbDeVies, ref Program.Joueur joueur)
        {

            Console.WriteLine("Votre joueur est-il:\n1-Un joueur humain\n2-Un ordinateur");
            joueur.type = (TypeJoueur)Convert.ToInt32(Console.ReadLine());
            if (joueur.type == TypeJoueur.Utilisateur)
            {
                Console.WriteLine("Quel est le nom de l'utilisateur?");
                joueur.nom = Console.ReadLine();
            }
            else if (joueur.type == TypeJoueur.Ordinateur)
            {
                Console.WriteLine("Quel nom voulez vous donner à cet ordinateur?");
                joueur.nom = Console.ReadLine();
            }
            joueur.main = new Program.Carte[3];
            joueur.total = new Program.Carte[5];
            for (int i = 0; i < joueur.main.Length; i++)
            {

                Program.GenererCarte(ref paquetCarte, ref joueur.main[i]);
            }

        }

        /*Initialise le paquet de carte*/
        public static void InitialiserPaquetCartes(ref Program.Carte[] paquetCarte)
        {
            int initialiseurSorte = 1, initialiseurNumero = 1;
            for (int i = 0; i < paquetCarte.Length; i++)
            {
                paquetCarte[i].sorte = (Sorte)initialiseurSorte;
                paquetCarte[i].numero = (Numero)initialiseurNumero;

                if (paquetCarte[i].numero == Numero.A)
                    paquetCarte[i].valeur = 11;
                else if (paquetCarte[i].numero >= Numero.J && paquetCarte[i].numero <= Numero.K)
                    paquetCarte[i].valeur = 10;
                else
                    paquetCarte[i].valeur = (int)paquetCarte[i].numero;
                initialiseurNumero++;

                if (initialiseurNumero == 14)
                {
                    initialiseurNumero = 1;
                    initialiseurSorte++;
                }
            }
        }

        /*Fonction qui met la console correctement*/

        public static void PreparerConsole()
        {
            Console.Title = "Jeux du 31";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetWindowSize(Console.LargestWindowWidth /2 , Console.LargestWindowHeight /2);
        }
    }
}
